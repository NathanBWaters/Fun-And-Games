#include "shader.h"
#include "math.h"

struct JS_panoramic 

{
	miScalar height;
	miScalar field_of_view;
	
};

DLLEXPORT int JS_panoramic_version(void) {return 1;}

DLLEXPORT miBoolean JS_panoramic(
  miColor *result,
  miState *state,
  struct JS_panoramic *paras
)
{
  miScalar uval, vval, rayx, rayy, rayz, camera_angle;
  miVector raydir, rayorig, rayorig_t, raydir_t;

  camera_angle = (360 - paras->field_of_view) * (M_PI / 360);
  uval = 2 * M_PI * state->raster_x / state->camera->x_resolution;
  uval = uval  * (paras->field_of_view /360);
  vval = state->raster_y / state->camera->y_resolution;

  rayx = -sin(uval + camera_angle);
  rayy = (vval - 0.5) * paras->height;
  rayz = cos(uval + camera_angle);

  raydir.x = rayx; 
  raydir.y = rayy; 
  raydir.z = rayz;
  mi_vector_from_camera(state, &raydir_t, &raydir);
  rayorig.x = 0; 
  rayorig.y = 0; 
  rayorig.z = 0;
  mi_point_from_camera(state, &rayorig_t, &rayorig);

  return (mi_trace_eye(result, state, &rayorig_t, &raydir_t));
}